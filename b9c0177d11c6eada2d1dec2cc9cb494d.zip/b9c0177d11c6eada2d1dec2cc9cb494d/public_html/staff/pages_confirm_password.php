<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
include('conf/config.php');
if (isset($_POST['confirm_reset_password'])) {
    $error = 0;
    if (isset($_POST['new_password']) && !empty($_POST['new_password'])) {
        $new_password = mysqli_real_escape_string($mysqli, trim(sha1(md5($_POST['new_password']))));
    } else {
        $error = 1;
        $err = "Parola nouă nu poate fi nimic!";
    }
    if (isset($_POST['confirm_password']) && !empty($_POST['confirm_password'])) {
        $confirm_password = mysqli_real_escape_string($mysqli, trim(sha1(md5($_POST['confirm_password']))));
    } else {
        $error = 1;
        $err = "Parola confirmată nu poate fi nimic!";
    }

    if (!$error) {
        $email = $_SESSION['email'];
        $sql = "SELECT * FROM  iB_staff  WHERE email = '$email'";
        $res = mysqli_query($mysqli, $sql);
        if (mysqli_num_rows($res) > 0) {
            $row = mysqli_fetch_assoc($res);
            if ($new_password != $confirm_password) {
                $err = "Parolele nu coencid!";
            } else {
                $email = $_SESSION['email'];
                $query = "UPDATE iB_staff SET  password =? WHERE email =?";
                $stmt = $mysqli->prepare($query);
                $rc = $stmt->bind_param('ss', $new_password, $email);
                $stmt->execute();
                if ($stmt) {
                    $success = "Parola a fost schimbată" && header("refresh:1; url=pages_staff_index.php");
                } else {
                    $err = "Încearcă mai târziu!";
                }
            }
        }
    }
}

$ret = "SELECT * FROM `iB_SystemSettings` ";
$stmt = $mysqli->prepare($ret);
$stmt->execute(); 
$res = $stmt->get_result();
while ($auth = $res->fetch_object()) {
?>
    <!DOCTYPE html>
    <html>
    <?php include("dist/_partials/head.php"); ?>

    <body class="hold-transition login-page">
        <div class="login-box">
            <div class="login-logo">
                <p><?php echo $auth->sys_name; ?> - <?php echo $auth->sys_tagline; ?></p>
            </div>
            <div class="card">
                <div class="card-body login-card-body">
                    <?php
                    $email  = $_SESSION['email'];
                    $ret = "SELECT * FROM  iB_staff  WHERE email = '$email'";
                    $stmt = $mysqli->prepare($ret);
                    $stmt->execute(); 
                    $res = $stmt->get_result();
                    while ($row = $res->fetch_object()) {
                    ?>
                        <p class="login-box-msg"><?php echo $row->name; ?> Introduceți parola</p>
                    <?php
                    } ?>
                    <form method="POST">
                        <div class="input-group mb-3">
                            <input type="password" required name="new_password" class="form-control" placeholder="Parola nouă">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-lock"></span>
                                </div>
                            </div>
                        </div>
                        <div class="input-group mb-3">
                            <input type="password" required name="confirm_password" class="form-control" placeholder="Confirmă parola">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-lock"></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <button type="submit" name="confirm_reset_password" class="btn btn-success btn-block">Resetează parola</button>
                            </div>
                        </div>
                    </form>

                    <p class="mt-3 mb-1">
                    </p>

                </div>
            </div>
        </div>
        <script src="lugins/jquery/jquery.min.js"></script>
        <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="dist/js/adminlte.min.js"></script>

    </body>

    </html>
<?php
} ?>