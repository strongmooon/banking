<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
include('conf/config.php');
if (isset($_POST['reset_password'])) {
  $error = 0;
  if (isset($_POST['email']) && !empty($_POST['email'])) {
    $email = mysqli_real_escape_string($mysqli, trim($_POST['email']));
  } else {
    $error = 1;
    $err = "Introduceți adresa dvs. de email";
  }
  if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
    $err = 'E-mail invalid';
  }
  $checkEmail = mysqli_query($mysqli, "SELECT `email` FROM `iB_clients` WHERE `email` = '" . $_POST['email'] . "'") or exit(mysqli_error($mysqli));
  if (mysqli_num_rows($checkEmail) > 0) {

    $n = date('y');
    $new_password = bin2hex(random_bytes($n));
    $query = "UPDATE iB_clients SET  password=? WHERE email =?";
    $stmt = $mysqli->prepare($query);
    $rc = $stmt->bind_param('ss', $new_password, $email);
    $stmt->execute();
    $_SESSION['email'] = $email;

    if ($stmt) {
      $success = "Confirmă parola" && header("refresh:1; url=pages_confirm_password.php");
    } else {
      $err = "Resetarea parolei a eșuat";
    }
  } else  
  {
    $err = "Acest e-mail nu există";
  }
}

$ret = "SELECT * FROM `iB_SystemSettings` ";
$stmt = $mysqli->prepare($ret);
$stmt->execute(); 
$res = $stmt->get_result();
while ($auth = $res->fetch_object()) {
?>
  <!DOCTYPE html>
  <html>
  <?php include("dist/_partials/head.php"); ?>

  <body class="hold-transition login-page">
    <div class="login-box">
      <div class="login-logo">
        <p><?php echo $auth->sys_name; ?> - <?php echo $auth->sys_tagline; ?></p>
      </div>
      <div class="card">
        <div class="card-body login-card-body">
          <p class="login-box-msg">Ți-ai uitat parola? Aici puteți recupera cu ușurință o nouă parolă.</p>

          <form method="POST">
            <div class="input-group mb-3">
              <input type="email" required name="email" class="form-control" placeholder="Email">
              <div class="input-group-append">
                <div class="input-group-text">
                  <span class="fas fa-envelope"></span>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-12">
                <button type="submit" name="reset_password" class="btn btn-success btn-block">Solicitați o nouă parolă</button>
              </div>
            </div>
          </form>

          <p class="mt-3 mb-1">
            <a href="pages_client_index.php">Loghează-te</a>
          </p>

        </div>
      </div>
    </div>


    <script src="lugins/jquery/jquery.min.js"></script>
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="dist/js/adminlte.min.js"></script>

  </body>

  </html>
<?php
} ?>