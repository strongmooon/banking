<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
include('conf/config.php');
include('conf/checklogin.php');
check_login();
$client_id = $_SESSION['client_id'];

?>
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<?php include("dist/_partials/head.php"); ?>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">
    <div class="wrapper">
        <?php include("dist/_partials/nav.php"); ?>
        <?php include("dist/_partials/sidebar.php"); ?>
        <?php
        $client_id = $_SESSION['client_id'];
        $ret = "SELECT * FROM  iB_clients WHERE client_id =? ";
        $stmt = $mysqli->prepare($ret);
        $stmt->bind_param('i', $client_id);
        $stmt->execute(); //ok
        $res = $stmt->get_result();
        $cnt = 1;
        while ($row = $res->fetch_object()) {

        ?>
            <div class="content-wrapper">
                <section class="content-header">
                    <div class="container-fluid">
                        <div class="row mb-2">
                            <div class="col-sm-6">
                                <h1><?php echo $row->name; ?> CapitaBank Cont</h1>
                            </div>
                            <div class="col-sm-6">
                                <ol class="breadcrumb float-sm-right">
                                    <li class="breadcrumb-item"><a href="pages_dashboard.php">Dashboard</a></li>
                                    <li class="breadcrumb-item"><a href="pages_balance_enquiries.php">Finances</a></li>
                                    <li class="breadcrumb-item"><a href="pages_balance_enquiries.php">Balances</a></li>
                                    <li class="breadcrumb-item active"><?php echo $row->name; ?> Accs</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </section>

                <section class="content">
  <div class="row">
    <?php
    $client_id = $_SESSION['client_id'];
    $ret = "SELECT * FROM iB_bankAccounts WHERE client_id = ?";
    $stmt = $mysqli->prepare($ret);
    $stmt->bind_param('i', $client_id);
    $stmt->execute(); 
    $res = $stmt->get_result();
    $cnt = 1;
    while ($row = $res->fetch_object()) {
      $dateOpened = $row->created_at;
    ?>
      <div class="col-12 col-md-6 col-lg-4">
        <div class="card mb-3">
          <div class="card-header">
            <h5 class="card-title"><?php echo $row->acc_name; ?></h5>
          </div>
          <div class="card-body">
            <p><strong>Nume: </strong><?php echo $row->acc_name; ?></p>
            <p><strong>Număr cont: </strong><?php echo $row->account_number; ?></p>
            <p><strong>Dobânda anuală: </strong><?php echo $row->acc_rates; ?>%</p>
            <p><strong>Tip cont: </strong><?php echo $row->acc_type; ?></p>
            <p><strong>Proprietar cont: </strong><?php echo $row->client_name; ?></p>
            <p><strong>Data deschiderii: </strong><?php echo date("d-M-Y", strtotime($dateOpened)); ?></p>
            <a class="btn btn-success btn-sm mt-2" href="pages_check_client_acc_balance.php?account_id=<?php echo $row->account_id; ?>&acccount_number=<?php echo $row->account_number; ?>">
              <i class="fas fa-eye"></i>
              <i class="fas fa-money-bill-alt"></i>
              Verifică Sold
            </a>
          </div>
        </div>
      </div>
    <?php $cnt = $cnt + 1;
    } ?>
  </div>
</section>

            </div>
        <?php } ?>
        <?php include("dist/_partials/footer.php"); ?>

        <aside class="control-sidebar control-sidebar-dark">
        </aside>
    </div>
    <script src="plugins/jquery/jquery.min.js"></script>
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="plugins/datatables/jquery.dataTables.js"></script>
    <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
    <script src="dist/js/adminlte.min.js"></script>
    <script src="dist/js/demo.js"></script>
    <script>
        $(function() {
            $("#example1").DataTable();
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
            });
        });
    </script>
</body>

</html>