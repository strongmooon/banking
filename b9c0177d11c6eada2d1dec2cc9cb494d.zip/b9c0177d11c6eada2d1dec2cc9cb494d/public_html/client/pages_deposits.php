<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
include('conf/config.php');
include('conf/checklogin.php');
check_login();
$client_id = $_SESSION['client_id'];
?>
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<?php include("dist/_partials/head.php"); ?>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">
  <div class="wrapper">
    <?php include("dist/_partials/nav.php"); ?>
    <?php include("dist/_partials/sidebar.php"); ?>
    <div class="content-wrapper">
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Depozituri</h1>
            </div>
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="pages_dashboard.php">Tabloul de Bord</a></li>
                <li class="breadcrumb-item"><a href="pages_deposits">CapitaBANK Finanțe</a></li>
                <li class="breadcrumb-item active">Depozituri</li>
              </ol>
            </div>
          </div>
        </div>
      </section>
      <section class="content">
        <div class="row">
          <?php
          $client_id = $_SESSION['client_id'];
          $ret = "SELECT * FROM  iB_bankAccounts  WHERE client_id = ?";
          $stmt = $mysqli->prepare($ret);
          $stmt->bind_param('i', $client_id);
          $stmt->execute(); //ok
          $res = $stmt->get_result();
          while ($row = $res->fetch_object()) {
            $dateOpened = $row->created_at;
          ?>
            <div class="col-md-4">
              <div class="card">
                  <div class="card-header">
                      <h3 class="card-title"><?php echo $row->acc_name; ?></h3>
                  </div>
                  <div class="card-body">
                      <p>Număr Card: <?php echo $row->account_number; ?></p>
                      <p>Dobânda anuală: <?php echo $row->acc_rates; ?>%</p>
                      <p>Tipul contului: <?php echo $row->acc_type; ?></p>
                      <p>Proprietar Card: <?php echo $row->client_name; ?></p>
                      <?php
                      if ($row->acc_type == "Depozit") {
                          echo '<img src="./dist/img/AdminLTELogo.png" alt="Card de Depozit" style="width:100%">';
                      }
                      ?>
                  </div>
                  <div class="card-footer">
                      <a class="btn btn-success btn-sm" href="pages_deposit_money.php?account_id=<?php echo $row->account_id; ?>&account_number=<?php echo $row->account_number; ?>&client_id=<?php echo $row->client_id; ?>">
                          <i class="fas fa-money-bill-alt"></i>
                          <i class="fas fa-upload"></i>
                          Depune Bani
                      </a>
                  </div>
              </div>
          </div>
          <?php } ?>
        </div>

      </section>
    </div>
    <?php include("dist/_partials/footer.php"); ?>
    <aside class="control-sidebar control-sidebar-dark">
    </aside>
  </div>

  <script src="plugins/jquery/jquery.min.js"></script>
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="plugins/datatables/jquery.dataTables.js"></script>
  <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
  <script src="dist/js/adminlte.min.js"></script>
  <script src="dist/js/demo.js"></script>
  <script>
    $(function() {
      $("#example1").DataTable();
      $('#example2').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
      });
    });
  </script>
</body>

</html>