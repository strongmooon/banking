<?php
    $dbuser="vlqdisdj_interne";
    $dbpass="Ihibis093967!";
    $host="localhost";
    $db="vlqdisdj_interne";
    $mysqli=new mysqli($host,$dbuser, $dbpass, $db);
